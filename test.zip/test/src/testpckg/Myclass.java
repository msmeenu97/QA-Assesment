package testpckg;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.login.Phonebook;
public class Myclass {
	
	
	public WebDriver driver;

	@Test()
	public void url () throws Exception{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Hp\\Documents\\jars\\chromedriver74\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		//driver.manage().window().maximize();
		driver.get("https://app.callhub.io/login/");
		driver.findElement(By.id("id_user")).sendKeys("msmeenu97@gmail.com");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.id("change-btn-text")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		driver.findElement(By.id("id_password")).sendKeys("Singh@11");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Thread.sleep(2000);
		driver.findElement(By.id("change-btn-text")).click();
		//sign in to the site
	
	
	//@Test(priority=0)
	//public void Phone() throws Exception{
		
		//Phonebook obj2 = new Phonebook(driver);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/nav/div[1]/ul/li[3]/a")).click();
		Thread.sleep(3000);
		//driver.findElement(By.xpath("/html/body/section/div[3]/div/a[1]")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//driver.findElement(By.name("name")).sendKeys("CallHub QA Test");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//driver.findElement(By.id("create-phonebook-btn")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//i[@class='icon-plus-sign']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(5000);

		driver.findElement(By.name("contact")).sendKeys("234567890");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElement(By.id("create-contact-btn")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//i[@class='icon-plus-sign']")).click();
		Thread.sleep(5000);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.name("contact")).sendKeys("987654320");
		driver.findElement(By.id("create-contact-btn")).click();

	}
	
	
}

