package com.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Phonebook {

	
	
	WebDriver driver;
	By phone = By.xpath("/html/body/nav/div[1]/ul/li[3]/a");
	
	
	
	
	public Phonebook(WebDriver driver)
	{
		this.driver=driver;
	}
	public void Phone(){
		driver.findElement(phone).click();
	}
}
