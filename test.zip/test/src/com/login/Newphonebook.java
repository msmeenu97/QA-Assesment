package com.login;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Newphonebook {

	
	WebDriver driver;
	By phone1 = By.xpath("/html/body/section/div[3]/div/a[1]");
	By phonenum1add = By.xpath("//i[@class='icon-plus-sign']");
	By ph1 = By.name("contact");
	By con = By.id("create-contact-btn");
	
	public Newphonebook(WebDriver driver)
	{
		this.driver=driver;
	}
	public void Phone(){
		driver.findElement(phone1).click();

	}
	public void clickadd ()
	{
	driver.findElement(phonenum1add).click();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	public void Ph1() throws InterruptedException{
		driver.findElement(ph1).sendKeys("234567890");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);
	}
	public void clickcontact() {

	driver.findElement(con).click();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

}

	public void Ph2() throws Exception{
		driver.findElement(ph1).sendKeys("234567890");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(2000);
	}
	
	
}
